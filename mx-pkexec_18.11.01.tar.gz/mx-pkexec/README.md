# mx-pkexec
pkexec wrapper for legacy apps

usage:

mx-pkexec appname  

QT variables related to theme should be preserved.
